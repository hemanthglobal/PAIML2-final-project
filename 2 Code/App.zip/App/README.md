# Workout logger (application layer)

Turns a recorded wrist session from RecGym into a workout log: one row per set, with a confidence score, and a flag asking the user to confirm sets the model may have got wrong.

## Requirements

Python 3 with `numpy`, `pandas`, `torch`, `scikit-learn` and `matplotlib`. The RecGym data is read from the Kaggle zip (`zhaxidelebsz/10-gym-exercises-with-615-abstracted-features`), by default at `../data/`. Pass `--data` to use another copy.

## Commands

```bash
python workout_app.py evaluate-all
```
For each of the 10 participants, trains a CNN on the other nine (if not already in `models/`) and logs all five of that person's sessions. Writes `output/all_subjects_sessions.csv` and `output/all_subjects_summary.csv`.

```bash
python workout_app.py log --subject 6 --session 2
```
Logs one session with the model that never saw that person. Writes `output/subject6_session2_log.csv` and `_timeline.png`.

```bash
python workout_app.py train --holdout 6
```
Trains one held-out CNN only.

Options: `--data <zip or csv>` (before the command), `--no-checks` (after `log`) turns off the set-length and movement checks.

On Colab: `python workout_app.py --data /content/recgym/RecGym.csv evaluate-all` (section 11 of `AIML Workout Extensions.ipynb`).

## Files

- `workout_app.py`: the application.
- `models/wrist_CNN_loso_results.npz`: wrist CNN LOSO results from the main notebook, used to decide which exercises generalise poorly.
- `output/`: saved results from the 11 November run on Colab.

Trained models and the window cache are rebuilt automatically when missing.

## Web interface (SetLog)

`ui_app.py` is a small Gradio web page on top of the app: pick a participant and session (or upload a CSV) and get the workout log as cards, with a **Confirm?** flag on uncertain sets and the timeline. Run it on Colab with `SetLog Demo.ipynb`, or:

```python
import sys; sys.path.insert(0, "/content/App")
import ui_app
ui_app.build("/content/recgym/RecGym.csv").launch(share=True)
```
