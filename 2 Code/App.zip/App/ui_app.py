"""SetLog: a small web interface for the workout logger (workout_app.py).

Pick a participant and session (or upload a recording) and get the workout log as
cards: one per set, with confidence and a "Confirm?" flag when the app is unsure.
The model used for a participant never saw that participant during training.

Run on Colab:
    import sys; sys.path.insert(0, "/content/App")
    import ui_app
    ui_app.build("/content/recgym/RecGym.csv").launch(share=True)
"""
import os
import html
import gradio as gr
import workout_app as wa

var_icons_dict = {
    "ArmCurl": "💪", "BenchPress": "🏋️", "Squat": "🏋️", "LegPress": "🦵", "LegCurl": "🦵",
    "Adductor": "🦵", "Riding": "🚴", "RopeSkipping": "🪢", "Running": "🏃",
    "StairClimber": "🪜", "Walking": "🚶",
}

CSS = """
.gradio-container {max-width: 480px !important; margin: 0 auto !important;
  font-family: -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif !important; background: #fff !important;}
footer {display: none !important;}
.sl-top {display:flex; justify-content:space-between; align-items:center; padding:8px 4px 4px;}
.sl-brand {font-size:22px; font-weight:700; letter-spacing:-0.3px; color:#000;}
.sl-bell {font-size:22px;}
.sl-h1 {font-size:28px; font-weight:700; letter-spacing:-0.5px; color:#000; margin:18px 0 2px;}
.sl-sub {font-size:16px; color:#5E5E5E; margin:0 0 14px;}
.sl-stats {display:flex; gap:10px; margin:6px 0 18px;}
.sl-stat {flex:1; background:#F3F3F3; border-radius:14px; padding:12px 14px;}
.sl-stat b {display:block; font-size:22px; color:#000;}
.sl-stat span {font-size:13px; color:#5E5E5E;}
.sl-list {border:1px solid #E8E8E8; border-radius:18px; overflow:hidden;}
.sl-row {display:flex; align-items:center; gap:14px; padding:12px 14px; border-top:1px solid #EEEEEE;}
.sl-row:first-child {border-top:none;}
.sl-ico {width:46px; height:46px; flex:none; border-radius:12px; background:#EEF3FD; border:1px solid #D7E2F8;
  display:flex; align-items:center; justify-content:center; font-size:22px;}
.sl-main {flex:1; min-width:0;}
.sl-name {font-size:17px; font-weight:700; color:#000;}
.sl-meta {font-size:13px; color:#5E5E5E;}
.sl-why {font-size:12px; color:#8A4B00;}
.sl-pill {font-size:13px; font-weight:600; border-radius:999px; padding:6px 12px; white-space:nowrap;}
.sl-ok {background:#F3F3F3; color:#000;}
.sl-ask {background:#000; color:#fff;}
.sl-truth {font-size:12px; margin-top:2px;}
.sl-good {color:#0E7A3E;} .sl-bad {color:#C0362C;}
.sl-h2 {font-size:22px; font-weight:700; color:#000; margin:26px 0 10px;}
.sl-chips {display:flex; flex-wrap:wrap; gap:8px;}
.sl-chip {background:#F3F3F3; border-radius:999px; padding:9px 14px; font-size:15px; color:#000;}
.sl-info {background:#EEF3FD; border:1px solid #D7E2F8; border-radius:18px; padding:18px 20px; margin-top:22px;}
.sl-info h3 {font-size:20px; font-weight:700; margin:0 0 10px; color:#000;}
.sl-info p {margin:8px 0; font-size:15px; color:#000;}
.sl-info p::before {content:"✓"; color:#276EF1; font-weight:700; margin-right:10px;}
.sl-empty {color:#5E5E5E; font-size:15px; padding:18px 4px;}
.sl-go {background:#000 !important; color:#fff !important; border:none !important; border-radius:12px !important;
  font-size:17px !important; font-weight:600 !important; min-height:52px !important;}
.sl-field input, .sl-field textarea, .sl-field .wrap {background:#F3F3F3 !important; border-radius:12px !important; border:none !important;}
.tab-nav button {font-size:16px !important; font-weight:600 !important;}
.tab-nav button.selected {border-bottom:3px solid #000 !important; color:#000 !important;}
"""

TOP = """<div class="sl-top"><span class="sl-brand">SetLog</span><span class="sl-bell">🔔</span></div>"""

INFO = """<div class="sl-info"><h3>Logged for you, checked by you</h3>
<p>Trained on 9 people, tested on someone it has never seen</p>
<p>Asks you to confirm sets it is unsure about</p>
<p>Knows how long and how hard each exercise usually is</p></div>"""

EMPTY = """<div class="sl-h1">Log a workout</div><div class="sl-sub">Choose a recorded session, then tap Log my workout.</div>""" + INFO


def render(var_log_df, var_metrics_dict, var_title_txt):
    """Workout log as cards, in the SetLog style."""
    var_has_truth_bool = "correct" in var_log_df.columns
    var_rows_list = []
    for _, r in var_log_df.iterrows():
        var_ex_txt = str(r["exercise"])
        var_flag_bool = r["status"] != "logged"
        var_why_txt = html.escape(r["status"].replace("CONFIRM: ", "")) if var_flag_bool else ""
        var_truth_html = ""
        if var_has_truth_bool:
            var_truth_html = ('<div class="sl-truth sl-good">✓ correct</div>' if r["correct"]
                              else f'<div class="sl-truth sl-bad">✗ was {html.escape("rest" if r["true_exercise"] == "Null" else str(r["true_exercise"]))}</div>')
        var_rows_list.append(
            f'<div class="sl-row"><div class="sl-ico">{var_icons_dict.get(var_ex_txt, "🏋️")}</div>'
            f'<div class="sl-main"><div class="sl-name">{html.escape(var_ex_txt)}</div>'
            f'<div class="sl-meta">{r["start"]} · {int(r["duration_s"])} s · {int(round(r["confidence"] * 100))}% sure</div>'
            + (f'<div class="sl-why">{var_why_txt}</div>' if var_flag_bool else "") + var_truth_html + '</div>'
            + ('<span class="sl-pill sl-ask">Confirm?</span>' if var_flag_bool else '<span class="sl-pill sl-ok">Logged</span>')
            + '</div>')
    var_sum_df = var_log_df.groupby("exercise").agg(sets=("exercise", "size"), secs=("duration_s", "sum"))
    var_chips_html = "".join(
        f'<span class="sl-chip">{var_icons_dict.get(e, "🏋️")} {html.escape(e)} · {int(s.sets)} set{"s" if s.sets > 1 else ""}</span>'
        for e, s in var_sum_df.sort_values("secs", ascending=False).iterrows())
    var_n_int = len(var_log_df)
    var_ask_int = int((var_log_df["status"] != "logged").sum())
    var_sub_txt = f'{var_metrics_dict.get("minutes", "?")} min recorded · the model never saw this person'
    var_check_html = ""
    if var_has_truth_bool:
        var_check_html = (f'<div class="sl-sub" style="margin-top:12px">Checked against the true labels: '
                          f'<b>{var_metrics_dict["sets_correct"]} of {var_n_int}</b> sets correct, '
                          f'{var_metrics_dict["wrong_flagged"]} of {var_metrics_dict["sets_wrong"]} wrong sets flagged, '
                          f'window macro F1 {var_metrics_dict["window_macro_f1"]:.3f}.</div>')
    return (f'<div class="sl-h1">{html.escape(var_title_txt)}</div><div class="sl-sub">{var_sub_txt}</div>'
            f'<div class="sl-stats"><div class="sl-stat"><b>{var_n_int}</b><span>sets logged</span></div>'
            f'<div class="sl-stat"><b>{var_ask_int}</b><span>to confirm</span></div>'
            f'<div class="sl-stat"><b>{len(var_sum_df)}</b><span>exercises</span></div></div>'
            f'<div class="sl-list">{"".join(var_rows_list) or "<div class=sl-empty>No sets found.</div>"}</div>'
            f'{var_check_html}<div class="sl-h2">Your workout at a glance</div><div class="sl-chips">{var_chips_html}</div>'
            + INFO)


def model_for(var_subject_int):
    # a CNN trained on the other nine people; trained once (about 2 minutes on a T4) if missing
    var_path_txt = f"{wa.var_modeldir_txt}/{wa.var_position_txt}_cnn_holdout{var_subject_int}.pt"
    if not os.path.exists(var_path_txt):
        wa.train(var_subject_int)
    return var_path_txt


def log_recorded(var_participant_txt, var_session_txt):
    var_subject_int = int(var_participant_txt.split()[-1])
    var_session_int = int(var_session_txt.split()[-1])
    var_log_df, var_metrics_dict = wa.log_session(model_for(var_subject_int), var_subject_int, var_session_int)
    var_png_txt = f"{wa.var_outputdir_txt}/subject{var_subject_int}_session{var_session_int}_timeline.png"
    return render(var_log_df, var_metrics_dict, f"Participant {var_subject_int}, session {var_session_int}"), var_png_txt


def log_upload(var_file_obj):
    if var_file_obj is None:
        return EMPTY, None
    var_path_txt = var_file_obj if isinstance(var_file_obj, str) else var_file_obj.name
    var_log_df, var_metrics_dict = wa.log_session(model_for(6), var_csvpath_txt=var_path_txt)
    var_name_txt = os.path.splitext(os.path.basename(var_path_txt))[0]
    return render(var_log_df, var_metrics_dict, "Your recording"), f"{wa.var_outputdir_txt}/{var_name_txt}_timeline.png"


def build(var_data_txt=None):
    if var_data_txt:
        wa.var_zippath_txt = var_data_txt
    with gr.Blocks(css=CSS, title="SetLog", theme=gr.themes.Base()) as var_demo_obj:
        gr.HTML(TOP)
        with gr.Tabs():
            with gr.Tab("Log"):
                with gr.Row():
                    var_p_obj = gr.Dropdown([f"Participant {i}" for i in range(1, 11)], value="Participant 6",
                                            show_label=False, elem_classes="sl-field", scale=3)
                    var_s_obj = gr.Dropdown([f"Session {i}" for i in range(1, 6)], value="Session 2",
                                            show_label=False, elem_classes="sl-field", scale=2)
                var_go_obj = gr.Button("Log my workout", elem_classes="sl-go")
            with gr.Tab("Upload"):
                gr.HTML('<div class="sl-sub">A CSV recording with columns A_x, A_y, A_z, G_x, G_y, G_z, C_1 at 20 Hz '
                        '(a Workout column, if present, is used to check the log).</div>')
                var_f_obj = gr.File(file_types=[".csv"], show_label=False)
                var_up_obj = gr.Button("Log my workout", elem_classes="sl-go")
        var_out_obj = gr.HTML(EMPTY)
        var_img_obj = gr.Image(show_label=False, interactive=False)
        var_go_obj.click(log_recorded, [var_p_obj, var_s_obj], [var_out_obj, var_img_obj])
        var_up_obj.click(log_upload, [var_f_obj], [var_out_obj, var_img_obj])
    return var_demo_obj


if __name__ == "__main__":
    import argparse
    var_parser_obj = argparse.ArgumentParser(description="SetLog web interface")
    var_parser_obj.add_argument("--data", help="RecGym zip or CSV")
    build(var_parser_obj.parse_args().data).launch(share=True)
