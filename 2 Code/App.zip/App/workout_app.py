"""Workout logger: the application layer on top of the PAIML2 pipeline.

Takes a recorded wrist session, classifies every 4 s window with the CNN, joins
consecutive windows of the same exercise into blocks (sets), and returns a workout
log with a confidence score per block. Blocks are flagged for the user to confirm
when confidence is low, or when the exercise is one that generalises poorly to new
people (wrist LOSO F1 below the threshold in the saved results).

The model, windowing and standardisation are the same as in AIML Workout Final.ipynb.

Two plausibility checks (added 11 Nov) also flag a set when it is much shorter than that
exercise's sets usually are, or shows less movement than that exercise usually does. Both
thresholds are learned from the training people only. They target the main failure found on
participant 6: rest periods logged as exercise with high confidence.

Usage:
    python workout_app.py train --holdout 6           # CNN trained on the other 9 people
    python workout_app.py log --subject 6 --session 2 # log a session of the held-out person
    python workout_app.py log --csv my_session.csv    # any recording with the 7 channels
    python workout_app.py evaluate-all                # every person, every session, own held-out model
    python workout_app.py --data /content/recgym/RecGym.csv evaluate-all   # on Colab
    python workout_app.py log --subject 6 --session 2 --no-checks          # October behaviour
"""
import os
import argparse
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import f1_score, accuracy_score

var_appdir_txt = os.path.dirname(os.path.abspath(__file__))
var_projectdir_txt = os.path.dirname(var_appdir_txt)
var_zippath_txt = f"{var_projectdir_txt}/data/10-gym-exercises-with-615-abstracted-features.zip"
var_lososresults_txt = f"{var_appdir_txt}/models/wrist_CNN_loso_results.npz"  # copy of results_final/wrist_CNN_results.npz, so App/ works on its own (e.g. on Colab)
var_modeldir_txt = f"{var_appdir_txt}/models"
var_cachedir_txt = f"{var_appdir_txt}/cache"
var_outputdir_txt = f"{var_appdir_txt}/output"

# settings, same as the notebook
var_seed_int = 42
var_window_int = 80       # 4 s at 20 Hz
var_stride_int = 40       # 2 s step
var_purity_float = 0.9    # training windows only
var_channels_list = ['A_x', 'A_y', 'A_z', 'G_x', 'G_y', 'G_z', 'C_1']
var_epochs_int = 40
var_batch_int = 256
var_lr_float = 1e-3
var_position_txt = "wrist"

# application settings
var_smooth_int = 5            # majority vote over 5 windows (about 12 s) removes one-window flickers
var_minblock_int = 3          # exercise blocks shorter than 3 windows (8 s) are merged into a neighbour
var_confidence_float = 0.80   # blocks below this mean confidence are flagged
var_weakf1_float = 0.86       # exercises with wrist LOSO F1 below this are always flagged
var_rest_txt = "Null"
var_durpct_float = 10         # a set shorter than the 10th percentile of that exercise's training sets is flagged
var_movepct_float = 5         # a set moving less than the 5th percentile of that exercise's training windows is flagged
var_minrun_float = 8.0        # training label runs shorter than 8 s are label noise, not sets

var_device_obj = torch.device("cuda" if torch.cuda.is_available() else "cpu")


class CNN(nn.Module):
    def __init__(self, var_nch_int, var_ncls_int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(var_nch_int, 64, 7, padding=3), nn.BatchNorm1d(64), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(64, 128, 5, padding=2), nn.BatchNorm1d(128), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(128, 256, 3, padding=1), nn.BatchNorm1d(256), nn.ReLU(),
            nn.AdaptiveAvgPool1d(1),
        )
        self.drop = nn.Dropout(0.3)
        self.head = nn.Linear(256, var_ncls_int)

    def forward(self, var_x_tensor):
        var_x_tensor = var_x_tensor.transpose(1, 2)  # Conv1d wants (batch, channels, time)
        var_x_tensor = self.net(var_x_tensor).squeeze(-1)
        return self.head(self.drop(var_x_tensor))


def standardise_windows(var_x_arr):
    # each channel to mean 0, std 1 within its own window
    var_mean_arr = var_x_arr.mean(axis=1, keepdims=True)
    var_std_arr = var_x_arr.std(axis=1, keepdims=True) + 1e-6
    return ((var_x_arr - var_mean_arr) / var_std_arr).astype(np.float32)


def class_weights(var_y_arr, var_ncls_int):
    # inverse frequency, training data only
    var_counts_arr = np.bincount(var_y_arr, minlength=var_ncls_int).astype(np.float32)
    return var_counts_arr.sum() / (var_ncls_int * np.maximum(var_counts_arr, 1))


var_datacache_df = None


def load_recgym():
    # read straight from the Kaggle zip (the unzipped CSV in data/ was cut short by Excel).
    # --data points to another copy, e.g. /content/recgym/RecGym.csv on Colab. Read once per run.
    global var_datacache_df
    if var_datacache_df is None:
        var_columns_list = ['Subject', 'Session', 'Position', 'Workout'] + var_channels_list
        var_data_df = pd.read_csv(var_zippath_txt, usecols=var_columns_list)
        var_datacache_df = var_data_df[var_data_df['Position'] == var_position_txt]
    return var_datacache_df


def movement(var_x_arr):
    # how much the wrist moves in each window: mean std of the three raw acceleration channels
    return var_x_arr[:, :, :3].std(axis=1).mean(axis=1)


def learn_checks(var_holdout_int, var_labels_list):
    # usual set length and usual movement for each exercise, from the training people only
    var_data_df = load_recgym()
    var_durations_dict = {}
    for (var_subject_int, _), var_group_df in var_data_df.groupby(['Subject', 'Session'], sort=False):
        if var_subject_int == var_holdout_int:
            continue
        var_lab_arr = var_group_df['Workout'].to_numpy()
        var_change_arr = np.flatnonzero(var_lab_arr[1:] != var_lab_arr[:-1]) + 1
        for var_run_arr in np.split(var_lab_arr, var_change_arr):
            var_seconds_float = len(var_run_arr) / 20
            if var_run_arr[0] != var_rest_txt and var_seconds_float >= var_minrun_float:
                var_durations_dict.setdefault(var_run_arr[0], []).append(var_seconds_float)
    var_x_arr, var_y_arr, var_subjects_arr, var_cachelabels_list = build_training_windows()
    var_move_arr = movement(var_x_arr)
    var_checks_dict = {}
    for var_label_int, var_label_txt in enumerate(var_cachelabels_list):
        if var_label_txt == var_rest_txt or var_label_txt not in var_durations_dict:
            continue
        var_mask_arr = (var_y_arr == var_label_int) & (var_subjects_arr != var_holdout_int)
        var_checks_dict[var_label_txt] = {
            "min_seconds": float(np.percentile(var_durations_dict[var_label_txt], var_durpct_float)),
            "min_movement": float(np.percentile(var_move_arr[var_mask_arr], var_movepct_float)),
        }
    return var_checks_dict


# ---------- training ----------

def build_training_windows():
    # same as build_windows in the notebook: inside each subject and session, purity filtered
    var_cachepath_txt = f"{var_cachedir_txt}/{var_position_txt}_w{var_window_int}_s{var_stride_int}.npz"
    if os.path.exists(var_cachepath_txt):
        print("Loading cached windows:", var_cachepath_txt)
        var_cache_npz = np.load(var_cachepath_txt, allow_pickle=True)
        return var_cache_npz['X'], var_cache_npz['y'], var_cache_npz['subjects'], list(var_cache_npz['labels'])

    print("Building training windows (runs once)")
    var_data_df = load_recgym()
    var_labels_list = sorted(var_data_df['Workout'].unique())
    var_labelmap_dict = {var_label_txt: i for i, var_label_txt in enumerate(var_labels_list)}
    var_x_list, var_y_list, var_subjects_list = [], [], []
    for (var_subject_int, _), var_group_df in var_data_df.groupby(['Subject', 'Session'], sort=False):
        var_signal_arr = var_group_df[var_channels_list].to_numpy(dtype=np.float32)
        var_label_arr = var_group_df['Workout'].map(var_labelmap_dict).to_numpy()
        for var_start_int in range(0, len(var_signal_arr) - var_window_int + 1, var_stride_int):
            var_counts_arr = np.bincount(var_label_arr[var_start_int:var_start_int + var_window_int],
                                         minlength=len(var_labels_list))
            if var_counts_arr.max() < var_purity_float * var_window_int:
                continue  # mixed window
            var_x_list.append(var_signal_arr[var_start_int:var_start_int + var_window_int])
            var_y_list.append(var_counts_arr.argmax())
            var_subjects_list.append(var_subject_int)

    var_x_arr, var_y_arr, var_subjects_arr = np.stack(var_x_list), np.array(var_y_list), np.array(var_subjects_list)
    os.makedirs(var_cachedir_txt, exist_ok=True)
    np.savez_compressed(var_cachepath_txt, X=var_x_arr, y=var_y_arr, subjects=var_subjects_arr,
                        labels=np.array(var_labels_list, dtype=object))
    return var_x_arr, var_y_arr, var_subjects_arr, var_labels_list


def train(var_holdout_int):
    torch.manual_seed(var_seed_int)
    var_x_arr, var_y_arr, var_subjects_arr, var_labels_list = build_training_windows()
    var_train_arr = np.where(var_subjects_arr != var_holdout_int)[0]  # the held-out person is never seen
    var_ncls_int = len(var_labels_list)
    print(f"Training CNN on {len(var_train_arr):,} windows, subject {var_holdout_int} held out, device {var_device_obj}")

    var_xtrain_arr = standardise_windows(var_x_arr[var_train_arr])
    var_ytrain_arr = var_y_arr[var_train_arr]
    var_loader_obj = torch.utils.data.DataLoader(
        torch.utils.data.TensorDataset(torch.tensor(var_xtrain_arr), torch.tensor(var_ytrain_arr)),
        batch_size=var_batch_int, shuffle=True)

    var_model_obj = CNN(var_x_arr.shape[2], var_ncls_int).to(var_device_obj)
    var_optimizer_obj = torch.optim.Adam(var_model_obj.parameters(), lr=var_lr_float)
    var_scheduler_obj = torch.optim.lr_scheduler.CosineAnnealingLR(var_optimizer_obj, T_max=var_epochs_int)
    var_lossfn_obj = nn.CrossEntropyLoss(
        weight=torch.tensor(class_weights(var_ytrain_arr, var_ncls_int)).to(var_device_obj))

    for var_epoch_int in range(var_epochs_int):
        var_model_obj.train()
        for var_xb_tensor, var_yb_tensor in var_loader_obj:
            var_xb_tensor, var_yb_tensor = var_xb_tensor.to(var_device_obj), var_yb_tensor.to(var_device_obj)
            var_optimizer_obj.zero_grad()
            var_lossfn_obj(var_model_obj(var_xb_tensor), var_yb_tensor).backward()
            var_optimizer_obj.step()
        var_scheduler_obj.step()
        if (var_epoch_int + 1) % 10 == 0:
            print(f"  epoch {var_epoch_int + 1}/{var_epochs_int}")

    os.makedirs(var_modeldir_txt, exist_ok=True)
    var_modelpath_txt = f"{var_modeldir_txt}/{var_position_txt}_cnn_holdout{var_holdout_int}.pt"
    torch.save({"state_dict": var_model_obj.state_dict(), "labels": var_labels_list,
                "holdout": int(var_holdout_int), "n_ch": int(var_x_arr.shape[2])}, var_modelpath_txt)
    print("Saved model to", var_modelpath_txt)


# ---------- logging a session ----------

def load_model(var_modelpath_txt):
    var_saved_dict = torch.load(var_modelpath_txt, map_location=var_device_obj, weights_only=False)  # own checkpoint, trusted
    var_model_obj = CNN(var_saved_dict['n_ch'], len(var_saved_dict['labels'])).to(var_device_obj)
    var_model_obj.load_state_dict(var_saved_dict['state_dict'])
    var_model_obj.eval()
    return var_model_obj, var_saved_dict['labels'], var_saved_dict['holdout']


def session_windows(var_signal_arr):
    # a real recording has no labels, so every window is kept (no purity filter)
    var_starts_list = list(range(0, len(var_signal_arr) - var_window_int + 1, var_stride_int))
    var_x_arr = np.stack([var_signal_arr[s:s + var_window_int] for s in var_starts_list])
    return var_x_arr, np.array(var_starts_list)


def predict(var_model_obj, var_x_arr):
    var_x_tensor = torch.tensor(standardise_windows(var_x_arr))
    var_probs_list = []
    with torch.no_grad():
        for i in range(0, len(var_x_tensor), var_batch_int):
            var_logits_tensor = var_model_obj(var_x_tensor[i:i + var_batch_int].to(var_device_obj))
            var_probs_list.append(torch.softmax(var_logits_tensor, dim=1).cpu())
    return torch.cat(var_probs_list).numpy()


def smooth(var_pred_arr, var_ncls_int):
    # majority vote in a sliding window, so a single odd window does not start a new set
    var_half_int = var_smooth_int // 2
    var_out_arr = var_pred_arr.copy()
    for i in range(len(var_pred_arr)):
        var_votes_arr = var_pred_arr[max(0, i - var_half_int):i + var_half_int + 1]
        var_out_arr[i] = np.bincount(var_votes_arr, minlength=var_ncls_int).argmax()
    return var_out_arr


def to_blocks(var_pred_arr):
    # runs of the same label: list of [label, first window, last window]
    var_blocks_list = []
    for i, var_label_int in enumerate(var_pred_arr):
        if var_blocks_list and var_blocks_list[-1][0] == var_label_int:
            var_blocks_list[-1][2] = i
        else:
            var_blocks_list.append([var_label_int, i, i])
    return var_blocks_list


def merge_short(var_pred_arr, var_rest_int):
    # exercise blocks under var_minblock_int windows take the label of the longer neighbour
    var_pred_arr = var_pred_arr.copy()
    for var_label_int, var_first_int, var_last_int in to_blocks(var_pred_arr):
        if var_label_int == var_rest_int or var_last_int - var_first_int + 1 >= var_minblock_int:
            continue
        var_left_int = var_pred_arr[var_first_int - 1] if var_first_int > 0 else var_rest_int
        var_right_int = var_pred_arr[var_last_int + 1] if var_last_int + 1 < len(var_pred_arr) else var_rest_int
        var_pred_arr[var_first_int:var_last_int + 1] = var_left_int if var_left_int != var_rest_int else var_right_int
    return var_pred_arr


def weak_exercises(var_labels_list):
    # exercises that generalise poorly to new people, from the saved 10-fold LOSO results
    if not os.path.exists(var_lososresults_txt):
        return set()
    var_results_npz = np.load(var_lososresults_txt, allow_pickle=True)
    return {str(l) for l, f in zip(var_results_npz['labels'], var_results_npz['per_class_loso'])
            if f < var_weakf1_float and str(l) != var_rest_txt}


def clock(var_seconds_float):
    return f"{int(var_seconds_float // 60):02d}:{int(var_seconds_float % 60):02d}"


def build_log(var_probs_arr, var_labels_list, var_x_arr=None, var_checks_dict=None):
    var_ncls_int = len(var_labels_list)
    var_move_arr = movement(var_x_arr) if var_x_arr is not None else None
    var_rest_int = var_labels_list.index(var_rest_txt)
    var_pred_arr = merge_short(smooth(var_probs_arr.argmax(axis=1), var_ncls_int), var_rest_int)
    var_weak_set = weak_exercises(var_labels_list)

    var_rows_list = []
    for var_label_int, var_first_int, var_last_int in to_blocks(var_pred_arr):
        if var_label_int == var_rest_int:
            continue
        var_exercise_txt = var_labels_list[var_label_int]
        # confidence: mean probability the model gives the block's exercise over the block's windows
        var_conf_float = float(var_probs_arr[var_first_int:var_last_int + 1, var_label_int].mean())
        var_reasons_list = []
        if var_conf_float < var_confidence_float:
            var_reasons_list.append("low confidence")
        if var_exercise_txt in var_weak_set:
            var_reasons_list.append("weak on new people")
        var_duration_float = ((var_last_int - var_first_int) * var_stride_int + var_window_int) / 20
        if var_checks_dict and var_exercise_txt in var_checks_dict:
            var_usual_dict = var_checks_dict[var_exercise_txt]
            if var_duration_float < var_usual_dict["min_seconds"]:
                var_reasons_list.append("shorter than usual")
            if var_move_arr is not None and \
               np.median(var_move_arr[var_first_int:var_last_int + 1]) < var_usual_dict["min_movement"]:
                var_reasons_list.append("less movement than usual")
        var_rows_list.append({
            "start": clock(var_first_int * var_stride_int / 20),
            "duration_s": int(var_duration_float),
            "exercise": var_exercise_txt,
            "confidence": round(var_conf_float, 2),
            "status": "CONFIRM: " + ", ".join(var_reasons_list) if var_reasons_list else "logged",
            "first_window": var_first_int,
            "last_window": var_last_int,
        })
    return pd.DataFrame(var_rows_list), var_pred_arr


def plot_timeline(var_pred_arr, var_true_arr, var_log_df, var_labels_list, var_title_txt, var_pngpath_txt):
    var_minutes_arr = np.arange(len(var_pred_arr)) * var_stride_int / 20 / 60
    var_cmap_obj = plt.get_cmap("tab20", len(var_labels_list))
    var_rest_int = var_labels_list.index(var_rest_txt)
    var_rows_list = [("Logged", var_pred_arr)] + ([("True", var_true_arr)] if var_true_arr is not None else [])
    var_fig_obj, var_ax_obj = plt.subplots(figsize=(13, 2.6 + 0.4 * len(var_rows_list)))
    for var_row_int, (var_name_txt, var_arr) in enumerate(var_rows_list):
        for var_label_int, var_first_int, var_last_int in to_blocks(var_arr):
            if var_label_int == var_rest_int:
                continue
            var_ax_obj.barh(var_row_int, var_minutes_arr[var_last_int] - var_minutes_arr[var_first_int] + 4 / 60,
                            left=var_minutes_arr[var_first_int], height=0.6, color=var_cmap_obj(var_label_int))
    for _, var_row_ser in var_log_df[var_log_df['status'] != "logged"].iterrows():
        var_ax_obj.text(var_minutes_arr[var_row_ser['first_window']], -0.45, "?", fontsize=12,
                        fontweight='bold', color="#C55A11", ha='left', va='center')
    var_ax_obj.set_yticks(range(len(var_rows_list)), [r[0] for r in var_rows_list])
    var_ax_obj.set_ylim(len(var_rows_list) - 0.5, -0.75)  # top row first, room for the ? marks
    var_ax_obj.set_xlabel("Minutes into session (rest left blank, ? = asked to confirm)")
    var_ax_obj.set_title(var_title_txt)
    var_used_list = sorted({int(l) for l in np.unique(var_pred_arr)} - {var_rest_int})
    var_ax_obj.legend([plt.Rectangle((0, 0), 1, 1, color=var_cmap_obj(i)) for i in var_used_list],
                      [var_labels_list[i] for i in var_used_list], ncol=6, frameon=False,
                      loc='upper center', bbox_to_anchor=(0.5, -0.35), fontsize=9)
    var_fig_obj.tight_layout()
    var_fig_obj.savefig(var_pngpath_txt, dpi=150, bbox_inches='tight')
    plt.close(var_fig_obj)


def true_sets(var_true_arr, var_rest_int):
    # true exercise sets in window terms, same 3-window minimum as the app uses
    return [b for b in to_blocks(var_true_arr) if b[0] != var_rest_int and b[2] - b[1] + 1 >= var_minblock_int]


def log_session(var_modelpath_txt, var_subject_int=None, var_session_int=None, var_csvpath_txt=None,
                var_checks_bool=True, var_quiet_bool=False, var_model_tuple=None, var_checks_dict=None):
    var_model_obj, var_labels_list, var_holdout_int = var_model_tuple or load_model(var_modelpath_txt)
    var_rest_int = var_labels_list.index(var_rest_txt)
    var_true_arr = None
    var_say = (lambda *a: None) if var_quiet_bool else print

    if var_csvpath_txt:
        var_session_df = pd.read_csv(var_csvpath_txt)
        var_name_txt = os.path.splitext(os.path.basename(var_csvpath_txt))[0]
    else:
        var_data_df = load_recgym()
        var_session_df = var_data_df[(var_data_df['Subject'] == var_subject_int)
                                     & (var_data_df['Session'] == var_session_int)]
        var_name_txt = f"subject{var_subject_int}_session{var_session_int}"
        if var_subject_int != var_holdout_int:
            print(f"WARNING: the model was trained on subject {var_subject_int}; "
                  f"use subject {var_holdout_int} for an honest new-person test")

    if var_checks_bool and var_checks_dict is None:
        var_checks_dict = learn_checks(var_holdout_int, var_labels_list)

    var_x_arr, var_starts_arr = session_windows(var_session_df[var_channels_list].to_numpy(dtype=np.float32))
    var_probs_arr = predict(var_model_obj, var_x_arr)
    var_log_df, var_pred_arr = build_log(var_probs_arr, var_labels_list, var_x_arr,
                                         var_checks_dict if var_checks_bool else None)

    # print the workout log
    var_say(f"\nWORKOUT LOG  {var_name_txt}  ({len(var_session_df) / 20 / 60:.1f} min recorded, "
            f"model never saw subject {var_holdout_int})")
    var_say(var_log_df[['start', 'duration_s', 'exercise', 'confidence', 'status']].to_string(index=False))
    var_summary_df = var_log_df.groupby('exercise').agg(sets=('exercise', 'size'), minutes=('duration_s', 'sum'))
    var_summary_df['minutes'] = (var_summary_df['minutes'] / 60).round(1)
    var_say("\nSummary\n" + var_summary_df.to_string())
    var_say(f"\n{(var_log_df['status'] != 'logged').sum()} of {len(var_log_df)} blocks need the user to confirm")

    var_metrics_dict = {"name": var_name_txt, "subject": var_subject_int, "session": var_session_int,
                        "minutes": round(len(var_session_df) / 20 / 60, 1), "sets_logged": len(var_log_df),
                        "flagged": int((var_log_df['status'] != 'logged').sum())}

    # when the recording has labels, check the log against them
    if 'Workout' in var_session_df.columns:
        var_labelmap_dict = {l: i for i, l in enumerate(var_labels_list)}
        var_rowlabels_arr = var_session_df['Workout'].map(var_labelmap_dict).to_numpy()
        var_true_arr = np.array([np.bincount(var_rowlabels_arr[s:s + var_window_int], minlength=len(var_labels_list)).argmax()
                                 for s in var_starts_arr])
        var_log_df['true_exercise'] = [
            var_labels_list[np.bincount(var_true_arr[r['first_window']:r['last_window'] + 1],
                                        minlength=len(var_labels_list)).argmax()]
            for _, r in var_log_df.iterrows()]
        var_log_df['correct'] = var_log_df['exercise'] == var_log_df['true_exercise']
        var_flag_ser = var_log_df['status'] != "logged"
        var_newflag_ser = var_log_df['status'].str.contains("shorter than usual|less movement than usual")
        # true sets the log missed: no logged block of the same exercise overlaps them
        var_missed_list = [var_labels_list[l] for l, a, b in true_sets(var_true_arr, var_rest_int)
                           if not ((var_log_df['exercise'] == var_labels_list[l])
                                   & (var_log_df['first_window'] <= b) & (var_log_df['last_window'] >= a)).any()]
        var_metrics_dict.update({
            "window_acc": round(accuracy_score(var_true_arr, var_pred_arr), 3),
            "window_macro_f1": round(f1_score(var_true_arr, var_pred_arr, average='macro', zero_division=0), 3),
            "true_sets": len(true_sets(var_true_arr, var_rest_int)),
            "sets_correct": int(var_log_df['correct'].sum()),
            "sets_wrong": int((~var_log_df['correct']).sum()),
            "wrong_were_rest": int(((~var_log_df['correct']) & (var_log_df['true_exercise'] == var_rest_txt)).sum()),
            "wrong_flagged": int((var_flag_ser & ~var_log_df['correct']).sum()),
            "correct_flagged": int((var_flag_ser & var_log_df['correct']).sum()),
            "wrong_flagged_by_new_checks": int((var_newflag_ser & ~var_log_df['correct']).sum()),
            "correct_flagged_by_new_checks": int((var_newflag_ser & var_log_df['correct']).sum()),
            "sets_missed": len(var_missed_list),
            "missed_exercises": ";".join(var_missed_list),
        })
        var_say("\nCheck against the true labels")
        var_say(f"  window accuracy {var_metrics_dict['window_acc']:.3f}, macro F1 {var_metrics_dict['window_macro_f1']:.3f}")
        var_say(f"  blocks correct: {var_metrics_dict['sets_correct']} of {len(var_log_df)}")
        var_say(f"  flagged blocks correct:   {var_log_df[var_flag_ser]['correct'].sum()} of {var_flag_ser.sum()}")
        var_say(f"  unflagged blocks correct: {var_log_df[~var_flag_ser]['correct'].sum()} of {(~var_flag_ser).sum()}")
        var_say(f"  wrong blocks caught by a flag: {var_metrics_dict['wrong_flagged']} of {var_metrics_dict['sets_wrong']}"
                f" ({var_metrics_dict['wrong_flagged_by_new_checks']} by the new length/movement checks)")
        var_say(f"  true sets missed: {var_metrics_dict['sets_missed']} {var_missed_list if var_missed_list else ''}")

    os.makedirs(var_outputdir_txt, exist_ok=True)
    var_log_df.drop(columns=['first_window', 'last_window']).to_csv(f"{var_outputdir_txt}/{var_name_txt}_log.csv", index=False)
    if not var_quiet_bool:
        plot_timeline(var_pred_arr, var_true_arr, var_log_df, var_labels_list,
                      f"Workout log for {var_name_txt} (new person to the model)",
                      f"{var_outputdir_txt}/{var_name_txt}_timeline.png")
        print(f"\nSaved {var_outputdir_txt}/{var_name_txt}_log.csv and _timeline.png")
    return var_log_df, var_metrics_dict


def evaluate_all():
    # every person, every session, each with a model that never saw that person
    var_data_df = load_recgym()
    var_rows_list = []
    for var_subject_int in sorted(var_data_df['Subject'].unique()):
        var_modelpath_txt = f"{var_modeldir_txt}/{var_position_txt}_cnn_holdout{var_subject_int}.pt"
        if not os.path.exists(var_modelpath_txt):
            train(var_subject_int)
        var_model_tuple = load_model(var_modelpath_txt)
        var_checks_dict = learn_checks(var_subject_int, var_model_tuple[1])
        for var_session_int in sorted(var_data_df.loc[var_data_df['Subject'] == var_subject_int, 'Session'].unique()):
            _, var_metrics_dict = log_session(var_modelpath_txt, int(var_subject_int), int(var_session_int),
                                              var_quiet_bool=True, var_model_tuple=var_model_tuple,
                                              var_checks_dict=var_checks_dict)
            var_rows_list.append(var_metrics_dict)
            print(f"  subject {var_subject_int:>2} session {var_session_int}: {var_metrics_dict['sets_correct']}/"
                  f"{var_metrics_dict['sets_logged']} sets correct, {var_metrics_dict['sets_wrong']} wrong "
                  f"({var_metrics_dict['wrong_flagged']} flagged), {var_metrics_dict['sets_missed']} missed, "
                  f"window macro F1 {var_metrics_dict['window_macro_f1']:.3f}")
        pd.DataFrame(var_rows_list).to_csv(f"{var_outputdir_txt}/all_subjects_sessions.csv", index=False)

    var_all_df = pd.DataFrame(var_rows_list)
    var_sum_cols_list = ['sets_logged', 'true_sets', 'sets_correct', 'sets_wrong', 'wrong_were_rest', 'wrong_flagged',
                         'wrong_flagged_by_new_checks', 'correct_flagged', 'correct_flagged_by_new_checks', 'sets_missed']
    var_person_df = var_all_df.groupby('subject')[var_sum_cols_list].sum()
    var_person_df['window_macro_f1'] = var_all_df.groupby('subject')['window_macro_f1'].mean().round(3)
    var_person_df.to_csv(f"{var_outputdir_txt}/all_subjects_summary.csv")
    var_tot_ser = var_all_df[var_sum_cols_list].sum()
    print("\nPer person (all sessions)\n" + var_person_df.to_string())
    print(f"\nALL 10 PEOPLE, {len(var_all_df)} sessions")
    print(f"  sets logged {var_tot_ser['sets_logged']}, correct {var_tot_ser['sets_correct']} "
          f"({var_tot_ser['sets_correct'] / var_tot_ser['sets_logged']:.1%}), wrong {var_tot_ser['sets_wrong']} "
          f"(of which rest logged as exercise: {var_tot_ser['wrong_were_rest']})")
    print(f"  wrong sets caught by a flag: {var_tot_ser['wrong_flagged']} of {var_tot_ser['sets_wrong']} "
          f"(new checks: {var_tot_ser['wrong_flagged_by_new_checks']})")
    print(f"  correct sets flagged (extra taps for the user): {var_tot_ser['correct_flagged']} "
          f"(new checks: {var_tot_ser['correct_flagged_by_new_checks']})")
    print(f"  true sets missed: {var_tot_ser['sets_missed']} of {var_tot_ser['true_sets']}")
    print(f"  window macro F1, mean over sessions: {var_all_df['window_macro_f1'].mean():.3f}")
    print(f"\nSaved {var_outputdir_txt}/all_subjects_sessions.csv and all_subjects_summary.csv")


if __name__ == "__main__":
    var_parser_obj = argparse.ArgumentParser(description="Workout logger with per-block confidence")
    var_parser_obj.add_argument("--data", help="RecGym zip or CSV (default: the Kaggle zip in ../data)")
    var_sub_obj = var_parser_obj.add_subparsers(dest="command", required=True)
    var_train_obj = var_sub_obj.add_parser("train", help="train the wrist CNN with one person held out")
    var_train_obj.add_argument("--holdout", type=int, default=6)
    var_log_obj = var_sub_obj.add_parser("log", help="turn a recorded session into a workout log")
    var_log_obj.add_argument("--subject", type=int)
    var_log_obj.add_argument("--session", type=int)
    var_log_obj.add_argument("--csv", help="a recording with columns " + ", ".join(var_channels_list))
    var_log_obj.add_argument("--model", default=f"{var_modeldir_txt}/{var_position_txt}_cnn_holdout6.pt")
    var_log_obj.add_argument("--no-checks", action="store_true", help="turn off the set-length and movement checks")
    var_sub_obj.add_parser("evaluate-all", help="every person and session, each with its own held-out model")
    var_args_obj = var_parser_obj.parse_args()

    if var_args_obj.data:
        var_zippath_txt = var_args_obj.data

    if var_args_obj.command == "train":
        train(var_args_obj.holdout)
    elif var_args_obj.command == "evaluate-all":
        evaluate_all()
    else:
        log_session(var_args_obj.model, var_args_obj.subject, var_args_obj.session, var_args_obj.csv,
                    var_checks_bool=not var_args_obj.no_checks)
